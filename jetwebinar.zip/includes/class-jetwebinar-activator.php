<?php

/**
 * Fired during plugin activation
 *
 * @link       http://www.jetwebinar.com
 * @since      1.0.0
 *
 * @package    Jetwebinar
 * @subpackage Jetwebinar/includes
 */

/**
 * Fired during plugin activation.
 *
 * This class defines all code necessary to run during the plugin's activation.
 *
 * @since      1.0.0
 * @package    Jetwebinar
 * @subpackage Jetwebinar/includes
 * @author     Brandon Burr <brandon@jetwebinar.com>
 */
class Jetwebinar_Activator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	 
	 
	public static function activate() {
	}

}
